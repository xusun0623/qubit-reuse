### Repo for quantum chiplet routing & scheduling

#### 难点（需讨论）

<!-- 1. SWAP对寻路的影响 -->

<!-- 2. DAG图关键路径的估算（节点权重的估算） -->

估算 + 最终跑的结果（由于它是 log 的，相差不会太大）

3. SWAP & CNOT 对调度的影响

4. GHZ 绕不过去，找到一个 SWAP 让路（最短路，让比特全部挪开）

#### 实验 Metric

1. 完成时间（DAG 运行时间）

2. SWAP 个数

3. GHZ 平均长度

##### 横坐标

1. 电路深度

2. 计算比特个数

3. 芯片大小

<!-- 4. 跨芯片的连接个数 -->

<!-- 2. 单门错误率

1. 物理比特开销

2. 敏感度（通过调整跨芯片保真度）分析 -->

#### 对比程序

QFT、QAOA、VQE、BV

#### 参数列表

program-261 square 324 6x6 3x3 program-360 square 441 7x7 3x3 program-495 square 576 8x8 3x3
program-630 square 729 9x9 3x3 program-160 square 196 7x7 2x2 program-240 square 294 7x7 2x3
program-480 square 588 7x7 3x4 program-420/366/288 square 486 9x9 2x3 program-312 hexagon 384 8x8
2x3 program-351 heavy square 432 8x8 3x3 program-336 heavy hexagon 480 8x8 3x4
