from copy import deepcopy
import queue
import random
import time
from chiplet import QPU
from tool import remove_root_node_from_dag, extract_first_layer
import networkx as nx
from docplex.mp.model import Model
import math


class Highway:
    '''对应的Highway'''

    def __init__(self, serve_dag_id, generate_time, live_time, ghz_link, last_serve_time):
        self.serve_dag_id: int = serve_dag_id  # 服务的 CNOT 节点
        self.generate_time: int = generate_time  # 开始生成的时间
        self.live_time: int = live_time  # GHZ态的存续时间
        # 相关的ghz链路，tuple中是物理比特ID
        self.ghz_link: list[tuple[int, int]] = ghz_link
        self.last_serve_time: int = last_serve_time  # 上一次服务的完成时间


# ⭐️ 优化选路
def select_path_for_given_CNOTs(qpu: QPU, cnots: list[list], dag_ids: list[int]):
    '''针对给定的一批CNOT门，选择唯一的路径'''
    '''传出：一批路径、对应的dag节点ID'''
    '''示例：[[0,3,5,7,9], [1,2,5,6]...], [3,6...]'''
    
    
    start_time = time.time()

    candidate_paths = []

    max_candidate_num = 3
    for cnot in cnots:
        # 选路的时候，给computation qubits加100的权重，使其尽可能绕过它
        tmp = qpu.get_k_path_with_qubit_id(
            source_qubit=cnot[0], target_qubit=cnot[1], k=max_candidate_num)
        candidate_paths.append(tmp)
    
    start_time_1 = time.time()

    cnot_length = len(cnots)
    conflict_graph = nx.Graph()

    for i in range(cnot_length):
        for j in range(max_candidate_num):
            conflict_graph.add_node((i, j))  # 使用 cnot索引 和 candidate索引 作为节点
            conflict_graph.nodes[(
                i, j)]['weight'] = qpu.circuit_dag.dag_nx.nodes[dag_ids[i]]["time_weight"]

    model = Model(name="select_max_weight")

    x_dim = [(i, j) for i in range(cnot_length)
             for j in range(max_candidate_num)]
    x = model.continuous_var_dict(x_dim, name="x", lb=0, ub=1)

    # 组内互斥
    for i in range(cnot_length):
        sum_expr = model.linear_expr()
        for j in range(max_candidate_num):
            sum_expr += x[i, j]
        model.add_constraint(sum_expr <= 1)
        

    # 构造冲突图，可以并行，忽略时间
    for i in range(cnot_length):
        for j in range(max_candidate_num):
            for _i in range(i, cnot_length):
                for _j in range(max_candidate_num):
                    if (i != _i or j != _j):
                        path = candidate_paths[i][j]
                        _path = candidate_paths[_i][_j]
                        if (is_two_path_conflict(path, _path)):
                            conflict_graph.add_edge((i, j), (_i, _j))
                            model.add_constraint(x[i, j] + x[_i, _j] <= 1)
                            


    objective_expr = model.linear_expr()
    for i in range(cnot_length):
        for j in range(max_candidate_num):
            objective_expr += x[i, j] * conflict_graph.nodes[(i, j)]['weight']

    model.maximize(objective_expr)

    selected_paths = []
    selected_dag_nodes = []

    start_time_2 = time.time()
    sol = model.solve()
    end_time = time.time()
    time_optimal = end_time - start_time_2 + (start_time_1 - start_time)/len(cnots)
    # print(f"time_optimal：{end_time - start_time_2 + start_time_1 - start_time}")
    
    if sol:
        while conflict_graph.number_of_nodes() > 0:
            max_ij_x = -1
            max_ij = (0, 0)
            for i in range(cnot_length):
                for j in range(max_candidate_num):
                    if (not conflict_graph.has_node((i, j))):
                        continue
                    tmp_multiple = x[i, j].solution_value * \
                        conflict_graph.nodes[(i, j)]['weight']
                    if tmp_multiple > max_ij_x:
                        max_ij_x = tmp_multiple
                        max_ij = (i, j)

            # 移除该节点以及与该节点冲突的所有节点
            neighbors = list(conflict_graph.neighbors(max_ij))
            conflict_graph.remove_node(max_ij)
            for __tmp in neighbors:
                conflict_graph.remove_node(__tmp)

            # 将最大的加入路径列表
            selected_paths.append(candidate_paths[max_ij[0]][max_ij[1]])
            selected_dag_nodes.append(dag_ids[max_ij[0]])

    # print(selected_paths)  # 打印选中的路径

    return selected_paths, selected_dag_nodes, time_optimal


def shuttle_for_cnot(qpu: QPU, cnot_paths, dag_node_ids, final_time_dag_optimal: nx.DiGraph, cnots_in_window, dag_node_id_in_window):
    '''⭐️ 优化调度'''
    '''给定：完整的QPU、CNOT路径数组、DAG节点ID数组、DAG图、动态被抽取的DAG图'''
    '''优化节点之间的调度，给DAG的节点打上时间标签'''
    '''返回：所需要的额外的Qubit数量'''
    path_num = len(cnot_paths)
    ancilla_qubit_num = 0

    all_paths = []

    for idx, cnot in enumerate(cnots_in_window):
        tmp = qpu.get_k_path_with_qubit_id(
            source_qubit=cnot[0], target_qubit=cnot[1], k=1)
        all_paths.append(tmp[0])

    def add_edge_to_dag(dag_node_id, cnot_path, eliminated_num):
        tmp_cnot_path = deepcopy(cnot_path)
        tmp_dag_node_id_in_window = deepcopy(dag_node_id_in_window)
        tmp_cnot_path = tmp_cnot_path[eliminated_num:-eliminated_num]
        for dag_node_id_idx, dag_neighbor_node_id in enumerate(tmp_dag_node_id_in_window):
            if (dag_neighbor_node_id in dag_node_ids):
                continue
            path = all_paths[dag_node_id_idx]
            if (is_two_path_conflict(path, tmp_cnot_path)):
                final_time_dag_optimal.add_edge(
                    dag_node_id, dag_neighbor_node_id, weight=1)

    for i in range(path_num):
        dag_node_id = dag_node_ids[i]
        cnot_path = cnot_paths[i]
        max_pre_time = 0
        for pre in final_time_dag_optimal.predecessors(dag_node_id):
            max_pre_time = max(
                max_pre_time, final_time_dag_optimal.nodes[pre]["process_done_time"])

        def estimate_swap_length(L):
            x = 0
            while 2**x + 2*x < L:
                x += 1
            if (x > 2):
                return 2
            return x

        L = len(cnot_path)
        eliminated_num = estimate_swap_length(L)
        # eliminated_num = 0
        cross_num = get_cross_computing_qubit_num(cnot_path, qpu)
        move_away_time = get_move_away_time(cnot_path, qpu)
        final_length = L - 2 * eliminated_num
        final_length = final_length if final_length > 1 else 1
        final_build_ghz_time = math.ceil(math.log2(final_length))
        final_time_dag_optimal.nodes[dag_node_id]["process_done_time"] = max_pre_time + \
            final_build_ghz_time + move_away_time
        ancilla_qubit_num += L - 2 * eliminated_num
        add_edge_to_dag(dag_node_id, cnot_path, eliminated_num)

    return ancilla_qubit_num


def schedule_optimal(original_qpu: QPU, callbackSchedulePath=None):
    '''⭐️ 优化调度，计算最后电路完成时间'''
    qpu: QPU = deepcopy(original_qpu)  # 先拷贝一份

    qpu.estimate_critical_value()  # 预估权重
    # ⭐️ 在调度的过程中，量子比特的映射会发生变化
    final_time_dag_optimal = deepcopy(qpu.circuit_dag.dag_nx)

    tmp_dag_optimal = deepcopy(qpu.circuit_dag.dag_nx)
    remove_root_node_from_dag(tmp_dag_optimal)
    has_remaining_cnot = True

    remain_GHZ_highway: list[Highway] = []  # 保留残存的GHZ Highway

    # swap_num = 0
    # ghz_length = 0
    ancilla_num = 0
    
    total_consume_times = []

    while has_remaining_cnot:
        # 抽取 Front Layer
        cnots_in_window, tmp_dag_with_attrs, dag_node_id_in_window, _has_remaining_cnot = extract_first_layer(
            tmp_dag_optimal)

        # 判断DAG图中是否有剩余的CNOT门没处理
        has_remaining_cnot = _has_remaining_cnot
        if (not has_remaining_cnot):
            break

        
        # ⭐️ 选路，这些路都是 non_conflict 的，以及他们的节点ID
        cnot_paths, dag_node_ids, select_path_time = select_path_for_given_CNOTs(
            qpu, cnots_in_window, dag_node_id_in_window)

        # print("time_optimal: ", end_time - start_time)
        
        time_start = time.time()
        # ⭐️ 调度路径
        ancilla_qubit_num = shuttle_for_cnot(
            qpu, cnot_paths, dag_node_ids, final_time_dag_optimal, cnots_in_window, dag_node_id_in_window)

        time_end = time.time()

        total_consume_times.append(time_end - time_start + select_path_time)
        
        ancilla_num += ancilla_qubit_num

        tmp_dag_optimal.remove_nodes_from(dag_node_ids)
        
        # print("diff_time_optimal: ", time_end - time_start)
        # print("select_path_time: ", select_path_time)
        
        
    print("time_optimal: ", sum(total_consume_times))
        
        
        

    max_depth = 0
    # 找出 self.final_depth_dag 出度为0的顶点
    for node in final_time_dag_optimal.nodes():
        if (final_time_dag_optimal.nodes[node]["process_done_time"] > max_depth):
            max_depth = final_time_dag_optimal.nodes[node]["process_done_time"]

    return max_depth, ancilla_num


def get_move_away_time(path, qpu: QPU):
    '''获取并行移动qubit所花费的时间'''
    # path - [物理比特, 物理比特, 物理比特...]
    merged_graph = qpu.merged_graph  # 物理比特拓扑
    map_plan = qpu.map_plan  # { 物理比特：计算比特 ... }

    for i in path:
        if (map_plan[i] != None):  # 存在已映射的计算比特，计算移走它花费的时间
            visited = set()
            visited.add(i)
            q = queue.Queue()
            q.put((i, 1))  # 第一个节点，第一层
            while (not q.empty()):
                cur_node = q.get()
                cur_node_id = cur_node[0]
                cur_node_depth = cur_node[1]
                if (map_plan[cur_node_id] == None):  # 找到一个没有被映射的节点
                    return cur_node_depth
                for neighbor in merged_graph.neighbors(cur_node_id):
                    if (neighbor not in visited):
                        visited.add(neighbor)
                        q.put((neighbor, cur_node_depth + 1))
    return 0


def get_cross_computing_qubit_num(path, qpu: QPU):
    '''获取穿过了的量子比特数'''
    count = 0
    for i in path:
        if (qpu.map_plan[i] != None):
            count += 1
    return count


def is_two_path_conflict(path1, path2) -> bool:
    # 使用set来判断是否冲突
    set_path1 = set(path1)
    for node in path2:
        if node in set_path1:
            return True
    return False
