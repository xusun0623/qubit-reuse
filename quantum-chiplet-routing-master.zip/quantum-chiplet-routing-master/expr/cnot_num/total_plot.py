import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

plt.rcParams.update({
    'font.size': 20,
    'font.family': 'serif',
    'font.serif': ['Times New Roman'],
    'svg.fonttype': 'none'
})


def plot_it(swap_vals, greedy_vals, optimal_vals, idx_ratio_1, optimal_ratio, optimal_ratio_1, x_labels, colors, border_colors, fig_name):
    colors = ['#436691', '#f7d27d', '#da695c']  # 分别对应 swap, greedy, optimal 的颜色
    border_colors = ["#081E38", "#312404", "#3e0b05"] # 分别对应 swap, greedy, optimal 的颜色
    
    swap_vals[:, 1] = swap_vals[:, 1] * np.array(idx_ratio_1)
    greedy_vals[:, 1] = greedy_vals[:, 1] * np.array(idx_ratio_1)
    optimal_vals[:, 0] = optimal_vals[:, 0] * np.array(optimal_ratio)
    optimal_vals[:, 1] = optimal_vals[:, 1] * \
        np.array(idx_ratio_1) * np.array(optimal_ratio_1)
    x = np.arange(len(x_labels))
    bar_width = 0.2
    offsets = np.array([-1.25, 0, 1.25]) * bar_width
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    scheme_names = ['SS', 'OGS', 'SHSQC']
    for i, vals in enumerate([swap_vals[:, 0], greedy_vals[:, 0], optimal_vals[:, 0]]):
        ax1.bar(x + offsets[i], vals, width=bar_width,
                color=colors[i], alpha=1.0, label=scheme_names[i], edgecolor=border_colors[i], linewidth=1)
        ax1.plot(x + offsets[i], vals, color=colors[i],
                 marker='o', markersize=8, linestyle='-', linewidth=2)
    for i, vals in enumerate([greedy_vals[:, 1], optimal_vals[:, 1]]):
        ax2.bar(x + offsets[i], vals, width=bar_width,
                color=colors[i], alpha=1.0, label=scheme_names[i], edgecolor=border_colors[i], linewidth=1)
        ax2.plot(x + offsets[i], vals, color=colors[i],
                 marker='o', markersize=8, linestyle='-', linewidth=2)
    ax1.set_ylabel('Execution Time', fontsize=24)
    ax2.set_ylabel('Avg. Ancilla Num', fontsize=24)
    ax2.set_xlabel('Number of CNOT Gates', fontsize=24)
    ax1.set_xticks(x)
    ax1.set_xticklabels([])  # 上子图不显示x轴标签
    ax2.set_xticks(x)
    ax2.set_xticklabels(x_labels)
    for ax in [ax1, ax2]:
        ax.yaxis.set_major_formatter(ticker.ScalarFormatter(useMathText=True))
        ax.yaxis.get_major_formatter().set_scientific(True)
        ax.yaxis.get_major_formatter().set_powerlimits((0, 0))
        ax.tick_params(axis='both', which='major', labelsize=24)
    ax1.legend(loc='upper left', fontsize=18)
    plt.tight_layout()
    plt.savefig(fig_name, format='pdf')
    plt.show()
