nohup python qubit_number_simple.py > log1.out 2>&1 &
nohup python circuit_depth_simple.py > log2.out 2>&1 &
nohup python chiplet_type_simple.py > log3.out 2>&1 &
