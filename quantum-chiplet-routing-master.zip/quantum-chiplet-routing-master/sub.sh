#!/bin/bash
#SBATCH -J  quantum_chiplet_routing
#SBATCH -p q_amd_share
#SBATCH -o %log.out
#SBATCH -e %log.err
#SBATCH -n 128

python -u main.py